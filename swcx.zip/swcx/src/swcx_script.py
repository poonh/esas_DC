import numpy as np
import commands
import os,sys,string
from swcx_commands import swcx_commands

mos1="mos1S001"
mos2="mos2S002"
pn="pnS003"

a=swcx_commands()


inner,outer=6,12 #inner and outer annuli in arcmin for extraction of lightcurves

newgti="mos1mos2-gti.txt"   #the new gti file for combined mos1 and mos2 lightcurves, the common gti has to be extracted first
a.timecheck("%s-gti.txt"%mos1,"%s-gti.txt"%mos2,newgti) #input the original mos1 and mos2 gti
a.newcleanfile(mos1,"%s-clean_SWCX.fits"%mos1,newgti.replace("txt","fits"))#the new clean fits(mos1S001-clean_SWCX.fits) produced with common mos1 and mos2 gti
a.newcleanfile(mos2,"%s-clean_SWCX.fits"%mos2,newgti.replace("txt","fits"))

mos1LClowE,mos1LChighE=a.Lightcurves(mos1,"%s-clean_SWCX.fits"%mos1,inner,outer)  #make a low energy and high energy lightcurve for the region (inner,outer). lowE=(0.5-0.7)keV,highE=(2.5-5)keV
mos2LClowE,mos2LChighE=a.Lightcurves(mos2,"%s-clean_SWCX.fits"%mos2,inner,outer)
pnLClowE,pnLChighE=a.Lightcurves(pn,"%s-clean.fits"%pn,inner,outer)

chimos1=float(a.LowvsHighLC(mos1LClowE,mos1LChighE,LClow2=None,LChigh2=None,Savefig="mos1-line-continuum.png",timebinsize=1000))#bin the lightcurves with a certain timebinsize and calculate the reduced chi square. The binning is 1 sec
chimos2=float(a.LowvsHighLC(mos2LClowE,mos2LChighE,LClow2=None,LChigh2=None,Savefig="mos2-line-continuum.png",timebinsize=1000))
chipn=float(a.LowvsHighLC(pnLClowE,pnLChighE,LClow2=None,LChigh2=None,Savefig="pn-line-continuum.png",timebinsize=1000))
chimos1mos2=float(a.LowvsHighLC(mos1LClowE,mos1LChighE,mos2LClowE,mos2LChighE,Savefig="mos1-mos2-line-continuum.png",timebinsize=1000)) #the reduced chi square for the combined mos1 and mos2 lightcurves

print("reduced chi square for mos1,mos2,pn and combined mos1 and mos2:")
print(chimos1,chimos2,chipn,chimos1mos2)

