import os,sys,string
import commands
import numpy as np
from astropy.io import fits
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def func(x, a, b):
    return a*x + b

class swcx_commands():
   def Lightcurves(self,ccd,cleanfile,inner,outer): #make a lightcurve in the region (inner,outer)arcmin. The binning is 1 sec
       outfile1="%s-LC-0.5-0.7keV-%s-%sam.fits"%(ccd,inner,outer) #lightcurve in (0.5-0.7)keV
       outfile2="%s-LC-2.5-5.0keV-%s-%sam.fits"%(ccd,inner,outer) #lightcurve in (2.5-5.0)keV
       inner,outer=inner*60./0.05,outer*60./0.05
       expr=""
       if ccd.find("S")>=0:
          ccdshort=ccd.split("S")[0]
       elif ccd.find("U")>=0:
          ccdshort=ccd.split("U")[0]
       if os.path.isfile(outfile1) == True:
          os.system("rm %s"%outfile1)
       if os.path.isfile(outfile2) == True:
          os.system("rm %s"%outfile2)
       if ccd.find("mos1")>=0 or ccd.find("mos2")>=0:
          ccd2=commands.getoutput("grep 'ccd2' InputFiles/goodccdlist_%s.dat | awk '{print $2}'"%ccdshort)
          if ccd2=="1":
             expr=expr+"(CCDNR==2)" 
          ccd3=commands.getoutput("grep 'ccd3' InputFiles/goodccdlist_%s.dat | awk '{print $2}'"%ccdshort)
          if ccd3=="1":
             expr=expr+"(CCDNR==3)" 
          ccd4=commands.getoutput("grep 'ccd4' InputFiles/goodccdlist_%s.dat | awk '{print $2}'"%ccdshort)
          if ccd4=="1":
             expr=expr+"(CCDNR==4)" 
          ccd5=commands.getoutput("grep 'ccd5' InputFiles/goodccdlist_%s.dat | awk '{print $2}'"%ccdshort)
          if ccd5=="1":
             expr=expr+"(CCDNR==5)" 
          ccd6=commands.getoutput("grep 'ccd6' InputFiles/goodccdlist_%s.dat | awk '{print $2}'"%ccdshort)
          if ccd6=="1":
             expr=expr+"(CCDNR==6)" 
          ccd7=commands.getoutput("grep 'ccd7' InputFiles/goodccdlist_%s.dat | awk '{print $2}'"%ccdshort)
          if ccd7=="1":
             expr=expr+"(CCDNR==7)" 
          expr= expr.replace(")(",")||(")
          os.system("evselect table=%s filtertype=expression expression='(PATTERN <= 12)&&(%s)&&(PI in [500:700])&&region(%s-bkg_region-sky.fits) && ((DETX,DETY) IN circle(155.661,285.833,%s)) &&! ((DETX,DETY) IN circle(155.661,285.833,%s))' filtertype=expression rateset=%s timecolumn=TIME timebinsize=1 maketimecolumn=yes makeratecolumn=yes withrateset=yes  >log/tmp.log"%(cleanfile,expr,ccd,outer,inner,outfile1))
          os.system("evselect table=%s filtertype=expression expression='(PATTERN <= 12)&&(%s)&&(PI in [2500:5000])&&region(%s-bkg_region-sky.fits) && ((DETX,DETY) IN circle(155.661,285.833,%s)) &&! ((DETX,DETY) IN circle(155.661,285.833,%s))' filtertype=expression rateset=%s timecolumn=TIME timebinsize=1 maketimecolumn=yes makeratecolumn=yes withrateset=yes  >log/tmp.log"%(cleanfile,expr,ccd,outer,inner,outfile2))
       elif ccd.find("pn")>=0:          
          os.system("evselect table=%s filtertype=expression expression='(PATTERN <= 4)&&(FLAG == 0)&&region(%s-bkg_region-sky.fits)&&(PI in [500:700]) && ((DETX,DETY) IN circle(285.8,719.722,%s)) &&! ((DETX,DETY) IN circle(285.8,719.722,%s))' filtertype=expression rateset=%s timecolumn=TIME timebinsize=1 maketimecolumn=yes makeratecolumn=yes withrateset=yes  >log/tmp.log"%(cleanfile,ccd,outer,inner,outfile1))
          os.system("evselect table=%s-clean.fits filtertype=expression expression='(PATTERN <= 4)&&(FLAG == 0)&&region(%s-bkg_region-sky.fits)&&(PI in [2500:5000]) && ((DETX,DETY) IN circle(285.8,719.722,%s)) &&! ((DETX,DETY) IN circle(285.8,719.722,%s))' filtertype=expression rateset=%s timecolumn=TIME timebinsize=1 maketimecolumn=yes makeratecolumn=yes withrateset=yes  >log/tmp.log"%(ccd,ccd,outer,inner,outfile2))
       return outfile1,outfile2
  
   def timecheck(self,gtimos1,gtimos2,outfile): #extract the common mos1 and mos2 gti and create a fits file
       mos1gti=file(gtimos1).readlines()
       mos2gti=file(gtimos2).readlines()
       if os.path.isfile(outfile) == True:
          os.system("rm %s"%outfile)
       mos1mos2gti=file(outfile,"w")
       timebegin1,timeend1,timebegin2,timeend2=[],[],[],[]
       timebegin,timeend=[],[]
       for i in mos1gti:
           timebegin1.append(float(i.split()[0]))
           timeend1.append(float(i.split()[1]))

       for i in mos2gti:
           timebegin2.append(float(i.split()[0]))
           timeend2.append(float(i.split()[1]))

       for i in range(0,len(timebegin1)):
           for j in range(0,len(timebegin2)):
              if timebegin1[i]==timebegin2[j] or (timebegin1[i]>timebegin2[j] and timebegin1[i]<timeend2[j]):
                  timebegin.append(timebegin1[i])
              if timeend1[i]==timeend2[j] or (timeend1[i]>timebegin2[j] and timeend1[i]<timeend2[j]):
                  timeend.append(timeend1[i])
              if (timeend2[j]>timebegin1[i] and timeend2[j]<timeend1[i]):
                  timeend.append(timeend2[j])
              if (timebegin2[j]>timebegin1[i] and timebegin2[j]<timeend1[i]):
                  timebegin.append(timebegin2[j])
       for i in range(0,len(timebegin)):
           mos1mos2gti.write(str(timebegin[i])+"   "+str(timeend[i])+"\n")
       mos1mos2gti.close()
       outfits=outfile.replace("txt","fits")
       if os.path.isfile(outfits) == True:
          os.system("rm %s"%outfits)
       os.system('ftcreate colname.lis %s %s extname = "STDGTI" clobber=yes'%(outfile,outfits))
       os.system("cphead %s+1 %s+1"%(gtimos1.replace("txt","fits"),outfits)) #this step is not necessary. I just want to avoid error
       os.system("cphead %s+0 %s+0"%(gtimos1.replace("txt","fits"),outfits))


   def newcleanfile(self,ccd,outfile,gti): #use the newly created gti (common gti for mos1 and mos2) to make a new clean file
        if os.path.isfile(outfile) == True:
           os.system("rm %s"%outfile)
        os.system("evselect table=%s-clean.fits filteredset=%s expression='(PATTERN<=12)&& GTI(%s,TIME) &&(((FLAG & 0x766a0f63)==0)||((FLAG & 0x766a0763) == 0))' filtertype=expression >log/tmp.log "%(ccd,outfile,gti))
    
   def LowvsHighLC(self,LClow,LChigh,LClow2=None,LChigh2=None,Savefig=None,timebinsize=None): #derive the reduced chi square. The lightcurve is binned in timebinsize
       if LClow2 is None and LChigh2 is None:
          FOVLClow = fits.open(LClow)[1].data
          ratelow=FOVLClow['RATE'];
          errlow=FOVLClow['ERROR'];
          timelow=FOVLClow['TIME']
          FOVLChigh = fits.open(LChigh)[1].data
          ratehigh=FOVLChigh['RATE'];
          errhigh=FOVLChigh['ERROR'];
          timehigh=FOVLChigh['TIME']
          combLClow=np.vstack((timelow,ratelow)).T
          combLChigh=np.vstack((timehigh,ratehigh)).T
  
       elif LClow2 is not None and LChigh2 is not None:
          FOVLClowmos1 = fits.open(LClow)[1].data
          ratelowmos1=FOVLClowmos1['RATE'];
          timelowmos1=FOVLClowmos1['TIME']
          FOVLChighmos1 = fits.open(LChigh)[1].data
          ratehighmos1=FOVLChighmos1['RATE'];
          timehighmos1=FOVLChighmos1['TIME']
          FOVLClowmos2 = fits.open(LClow2)[1].data
          ratelowmos2=FOVLClowmos2['RATE'];
          timelowmos2=FOVLClowmos2['TIME']
          FOVLChighmos2 = fits.open(LChigh2)[1].data
          ratehighmos2=FOVLChighmos2['RATE'];
          timehighmos2=FOVLChighmos2['TIME']
          mos1LClow=np.vstack((timelowmos1,ratelowmos1)).T
          mos1LChigh=np.vstack((timehighmos1,ratehighmos1)).T
          mos2LClow=np.vstack((timelowmos2,ratelowmos2)).T
          mos2LChigh=np.vstack((timehighmos2,ratehighmos2)).T
          combLClow=np.asarray(mos1LClow.tolist()+mos2LClow.tolist())
          combLChigh=np.asarray(mos1LChigh.tolist()+mos2LChigh.tolist())

       bins = np.arange(np.min(combLClow[:,0]),np.max(combLClow[:,0]),timebinsize)
       ratelow,ratehigh,errlow,errhigh=[],[],[],[]
       for i in range(1,len(bins)+1):
           binassignlow= combLClow[np.digitize(combLClow[:,0],bins)==i]
           binassignhigh= combLChigh[np.digitize(combLChigh[:,0],bins)==i]
           time=bins[i-1]+timebinsize/2.
           ratelow.append(np.sum(binassignlow[:,1])/timebinsize)
           errlow.append(np.sqrt(np.sum(binassignlow[:,1]))/timebinsize)
           ratehigh.append(np.sum(binassignhigh[:,1])/timebinsize)
           errhigh.append(np.sqrt(np.sum(binassignhigh[:,1]))/timebinsize)
       ratelow=np.asarray(ratelow)
       ratehigh=np.asarray(ratehigh)
       errlow=np.asarray(errlow) 
       errhigh=np.asarray(errlow)
       popt, pcov = curve_fit(func, ratehigh,ratelow)
       model_Y=func(ratehigh,popt[0],popt[1])
       sum,num=0,0
       for i in range(0,len(model_Y)):
           if errlow[i]!=0:
               sum=sum+((model_Y[i]-ratelow[i])**2/((errlow[i])**2))
               num=num+1
       reducedchi=sum/(float(num)-2)
       plt.clf()
       plt.tick_params(length=5, width=1, which='minor', direction='in', right=True, top=True)
       plt.tick_params(length=5, width=1, which='major', direction='in', right=True, top=True)  
#       plt.tick_params(right="true",which='minor',color='k')
#       plt.tick_params(right="true",which='major', color='k')
#       plt.tick_params(top="true",which='minor', color='k')
#       plt.tick_params(top="true",which='major', color='k')
       plt.errorbar(ratehigh, ratelow, xerr=errhigh, yerr=errlow, linestyle='None', marker='x')
       plt.plot(ratehigh, model_Y)
       plt.xlabel("Continnum band count rate ct $s^{-1}$",fontsize=12)
       plt.ylabel("Line band count rate ct $s^{-1}$",fontsize=12)
       if Savefig is not None:
           plt.savefig(Savefig)
       plt.show()
       return "{:.3f}".format(reducedchi)

   
 
