import os
from os import *
from sys import *
import commands
import numpy as np
from filter_sp_commands import filter_sp_commands


#========================================================
#write the results of mos-filter to InputFiles/goodccdlist_mos1/mos2.txt, which will be used for mos-spectra.
#a.write_ccd_anol("mosproblemccd.txt") #mosproblemccd.txt is the command.csh file after you run mos-filter
#========================================================

CCD=argv[1]
a=filter_sp_commands()
elow=2.5 #in keV
ehigh=12.0

#========================================================
#filter the unfiltered event list mos1S001-ori.fits for soft flare protons by making a gaussian fit to the photon counts of the FOV lightcurves
inputfile="%s-ori.fits"%CCD   #product of emchain/epchain, which is an unfiltered event list
LC=a.Lightcurves("FOV",inputfile,elow,ehigh)   #produce the FOV LCs from the inputfile in the energy range:[elow,ehigh]. Enter either "FOV" or "corner"
LCcorn=a.Lightcurves("corner",inputfile,elow,ehigh) #produce the corner LCs
a.make_gti(CCD,LC,LCcorn,elow,ehigh,binsize=60,sig=2,histogram_bin=0.05,fit_limit=1.4,pltshow="False")#the gti text file is created here. It also creates a plot showing the histogram with a gaussian fit called mos1S001_2.5_12.0_gti_ED.png. binsize in seconds, signifance = 2sigma. See the code for details
a.txt2fits("%s_gti_ED.txt"%CCD,"%s_gti_ED.fits"%CCD)  #convert gti text file to fits using ftcreate
#========================================================

#========================================================
#make the final product - mos1S001-clean.fits
a.make_Clean(CCD,"%s_gti_ED.fits"%CCD)#name of the final product is "%s-clean_ED.fits"%CCD, created using evselect with the gti file input as the 2nd parameter
#========================================================
